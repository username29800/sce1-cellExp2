# 1. pre-boot POST routine
# core modules loader
import utils, sys, os

# self integrity check
os.system('python keepalive.py')